#include <assert.h>
#include <iostream>
#include "UI.h"

void testEvent();
//void testDynamicVector();
void testRepository();
void testService();
void runAllTests();